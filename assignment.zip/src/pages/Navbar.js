import React, { useState } from 'react'

export default function Navbar() {
    const [mobile, setmobile] = useState(false)
    return (
        <div className='main-container'>
          <div className={mobile ? 'nav-link-mobile': 'nav-link'}
            onClick={() => setmobile(false)}
          >
        <div className='part1'>
          <div className='box-one'><img src='./img/m.png' className='img-logo'/></div>
          <div className='part2'>
          <div className='box-three'><img src='./img/1.png' className='img-data'/><br/><span className='font-side-one'>NEW</span></div>
          <div className='box-two'><img src='./img/2.png' className='img-data'/><br/><span className='font-side'>PATIENT</span></div>
          <div className='box-two'><img src='./img/3.png' className='img-data'/><br/><span className='font-side'>FOLDER</span></div>
          <div className='box-two'><img src='./img/4.png' className='img-data'/><br/><span className='font-side'>UPLOAD</span></div>
          <div className='box-two'><img src='./img/5.png' className='img-data'/><br/><span className='font-side'>REPORT</span></div>
          <div className='box-two'><img src='./img/6.png' className='img-data'/><br/><span className='font-side'>SETTING</span></div>
          <div className='box-two'><img src='./img/7.png' className='img-data'/><br/><span className='font-side'>LOGOUT</span></div>
        </div>
        </div>
        </div>
        <button className='btn-hide'
        onClick={() => setmobile(!mobile)}>
          {mobile ? (
            <i className='fas fa-times'></i>
          ):(
            <i className='fas fa-bars'></i>
          )}
        </button>
      </div>
  )
}
