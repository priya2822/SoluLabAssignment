import React from 'react'

export default function Profile() {
  return (
    <>
    <div className='container-profile'>
        <div className='profile-one'>
            <div className='pro-data'>
                <img src='./img/profile.png' className='pro-img' />
            </div>
            <div>
                <h1 className='pro-name'>Diane Cooper</h1>
                <p className='mail-font'>diane.cooper@example.com</p>
            </div>
            <div className='appoint-profile'>
                <div className='box-appo'><h2 className='appo-data'>15</h2><div className='appo-data-font'>past</div></div>
                <div className='border-line'></div>
                <div><h2 className='upcoming-appo'>02</h2><div className='upcoming-appo-data'>Upcoming</div></div>
            </div>
        </div>
        <div className='btn-style'>
            <div className='box-btn'>
                <div className='btn-data'>Send Message</div>
            </div>
        </div>
        <div className='btn-style'>
            <div className='doc-data'>
                Files / Documents
            </div>
            <div className='doc-col-data'>
                <div className='doc-column'><spn className='doc-font'><i class="fa-solid fa-file-lines"></i> Check Up Results.pdf</spn></div>
                <div className='doc-column'><spn className='doc-font'><i class="fa-solid fa-file-lines"></i> Check Up Results.pdf</spn></div>
                <div className='doc-column'><spn className='doc-font'><i class="fa-solid fa-file-lines"></i> Medical Prescription.pdf</spn></div>
                <div className='doc-column'><spn className='doc-font'><i class="fa-solid fa-file-lines"></i> Dental X-Ray Result.pdf</spn></div>
            </div>
        </div>
    </div>
</>
    )
}
