import React from 'react'

export default function Info() {
  return (
    <>
            <div className='container-info'>
                <div className='info-cont'>
                    <div class="info-container-one">
                        <div>
                            <div className='con-one-data'>Gender</div><div className='con-two-data'>Female</div><hr /></div>
                        <div className='box-info'>
                            <div className='container-one-data-row1'><spn>Birthday</spn></div> <div className='container-data-font1'>Feb,24th,1997</div><hr /></div>
                        <div>
                            <div className='container-one-data-row2'><spn>Phone</spn></div> <div className='container-data-font2' id='one-data'>(239),555-0108</div><hr /></div>
                        <div>
                            <div className='container-one-data-row3'><span>Registered</span></div> <div className='container-data-font3'>Feb,24th,1997</div><hr /></div>
                    </div>
                    <div class="info-container-one">
                        <div>
                            <div className='container-five-data1'>Street Address</div><div className='container-five-data'>JL. Diponegoro</div><hr /></div>
                        <div >
                            <div className='container-two-data'><span>City</span></div> <div className='container-data-font4'>Cilacap</div><hr /></div>
                        <div>
                            <div className='container-three-data'>Zip Code</div> <div className='container-data-font5'>655849</div><hr /></div>
                        <div>
                            <div className='container-four-data'>Member Status</div> <div className='container-data-font6'>Active Member</div><hr /></div>
                    </div>
                    <div class="info-container-two">
                        <div>
                            <div className='container-six-data'>Upcoming Appointments</div></div>
                        <div>
                            <div className='container-seven-data'>Past Appointments</div></div>
                        <div>
                            <div className='container-seven-data'>Medical Records</div></div>
                    </div>
                    <div class="info-container-three">
                        <div className='con-row-one'>
                            <div className='con-data-one'>Root Canal Treatment</div>
                            <div className='con-data-two'>Show Previous Treatments</div></div><hr />
                        <div className='container-row-two'>
                            <div className='container-row-co'><h4 className='con-data-three'>26 Nov ‘19</h4>
                                <div className='con-data-four'>09.00 - 10.00</div></div>
                            <div className='border-line'></div>
                            <div className='container-row-co'><div className='con-data-five'>Treatment</div>
                                <div className='con-data-six'>Open Access</div></div>
                            <div className='border-line'></div>
                            <div className='container-row-co'><div className='con-data-five'>Dentist</div>
                                <div className='con-data-seven'>Drg. Adam H.</div></div>
                            <div className='container-row-co'><div className='con-data-five'>Nurse</div>
                                <div className='con-data-seven'>Jessicamila</div></div>
                        <div className='container-row-not'><div className='con-data-icon'><i class="fa-solid fa-file-lines"></i>   Note</div></div>
                        </div>
                        <div className='container-row-three'>
                            <div className='container-row-co'><h4 className='con-data-three'>12 Nov ‘19</h4>
                                <div className='con-data-four'>09.00 - 10.00</div></div>
                            <div className='border-line'></div>
                            <div className='container-row-co'><div className='con-data-five'>Treatment</div>
                                <div className='con-data-six'>Root Canal</div></div>
                            <div className='border-line'></div>
                            <div className='container-row-co'><div className='con-data-five'>Dentist</div>
                                <div className='con-data-seven'>Drg. Adam H.</div></div>
                            <div className='container-row-co'><div className='con-data-five'>Nurse</div>
                                <div className='con-data-seven'>Jessicamila</div></div>
                                <div className='container-row-not'><div className='con-data-icon'><i class="fa-solid fa-file-lines"></i>   Note</div></div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
