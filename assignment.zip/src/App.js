import logo from './logo.svg';
import './App.css';
import './pages/Info.css';
import './pages/Profile.css';
import Navbar from './pages/Navbar';
import Profile from './pages/Profile';
import Info from './pages/Info';

function App() {
  return (
    <div className='container'>

    <Navbar/>
    <Profile/>
    <Info/>
    </div>
  );
}

export default App;
